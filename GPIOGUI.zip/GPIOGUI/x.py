from functools import partial
